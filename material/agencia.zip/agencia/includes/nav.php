<nav class="site-header sticky-top py-2">
    <div class="container d-flex flex-column flex-md-row justify-content-between">
        <a href="index.php" class="mt-1">
            <i class="fab fa-meetup fa-2x"></i>
        </a>


        <a class="py-2" href="adminRegiones.php">Regiones</a>
        <a class="py-2" href="adminDestinos.php">Destinos</a>


        <button class="btn btn-dark">
            <a href="formLogin.php"><i class="fas fa-sign-in-alt mr-2"></i> Ingresar</a>
        </button>

<!-- logueado
        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <a href="#"><i class="fas fa-sign-out-alt"></i>
                Nombre Apellido
            </a>
        </button>
            <div class="dropdown-menu bg-dark" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item bg-dark" href="logout.php">Salir de sistema</a>
                <a class="dropdown-item bg-dark" href="">Modificar Perfil</a>
                <a class="dropdown-item bg-dark" href="">Cambiar contraseña</a>
            </div>
-->

    </div>
</nav>
