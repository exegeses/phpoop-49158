<?php
    require 'config/config.php';
    include 'includes/over-all-header.html';
    include 'includes/nav.php';
?>

    <main class="container">

        <h1>Tema de la página</h1>

            <p class="lead">En este bloque desarrollaremos el contenido principal</p>
            <p class="lead">
                <a href="#" class="btn btn-lg btn-outline-secondary">más info.</a>
            </p>

    </main>

<?php
    include 'includes/footer.php';
?>